package ExcptionHandling;

public class TestException {
	public int divide(int n ,int i) throws Exception{
		int div= n/i;
		return div;
	}
	public static void main(String[] args) {
		
		TestException t = new TestException();
			try
			{
				int s = t.divide(14,2);
				System.out.println(s);
			}catch(Exception e){
				System.out.println("Cant divide");
			}
		System.out.println("Excute");
	}

}
