package beans;

public class Employee implements Comparable<Employee> {
	private int empid;
	private String ename;
	private String email;
	private double sal;
	
	public Employee() {
		super();
	}
	public Employee(int empid, String ename, String email, double sal) {
		this.empid = empid;
		this.ename = ename;
		this.email = email;
		this.sal = sal;
	}
	
	public Employee(int id) {
		this.empid = empid;
		this.ename = null;
		this.email = null;
		this.sal = 0;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		System.out.println("in employee equals "+this.empid+"----"+((Employee)obj).empid);
		return empid==((Employee)obj).empid;
	}
	
	
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", email=" + email + ", sal=" + sal + "]";
	}
	@Override
	public int compareTo(Employee o) {
		System.out.println("in compareTo method"+this.sal+","+o.sal);
		if(this.sal<o.sal) {
			return -1;
		}
		else if(this.sal==o.sal) {
			return 0;
		}
		else
			return 1;
	}
	
}
