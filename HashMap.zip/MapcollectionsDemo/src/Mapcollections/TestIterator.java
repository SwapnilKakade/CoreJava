package Mapcollections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestIterator {

	public static void main(String[] args) {
	List<Integer> lst = new ArrayList<>();
	lst.add(10);
	lst.add(20);
	lst.add(30);

	for(Integer ob : lst) {
		System.out.println(ob);
	}
	
	Iterator <Integer> it = lst.iterator();
	while(it.hasNext()) {
		Integer d = it.next();
		if(d == 10) {
			it.remove();
			System.out.println();
		}
	}
	}

}
