package service;
import java.util.Map;
import java.util.Set;

import beans.Employee;
public interface EmployeeService {

	void AddNewEamployee();

	Map<Integer, Employee> displayAll();

	Employee SearchById(int empid);

	Set<Employee> SearchByName(String ename);

	Set<Employee> SortBySal();

	Set<Employee> SortByName();

}
