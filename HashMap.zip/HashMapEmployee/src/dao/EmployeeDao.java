package dao;

import java.util.Map;
import java.util.Set;

import beans.Employee;

public interface EmployeeDao {

	void save(Employee e);

	Map<Integer, Employee> getAll();

	Employee SearchById(int empid);

	Set<Employee> SearchByName(String ename);

	Set<Employee> SortBySal();

	Set<Employee> SortByName();

}
