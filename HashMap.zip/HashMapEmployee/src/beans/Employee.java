package beans;

public class Employee implements Comparable<Employee> {
	private int empid;
	private String ename ;
	private String email ;
	private double sal ;
	public Employee() {
		super();
	}

	public Employee(int empid) {
		super();
		this.empid = empid;
		this.ename = null;
		this.email = null;
		this.sal = 0;
	}
	public Employee(int empid, String ename, String email, double sal) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.email = email;
		this.sal = sal;
	}
	
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", email=" + email + ", sal=" + sal + "]";
	}
	@Override
	public int compareTo(Employee o) {
		System.out.println("in compare to method "+this.empid +"------"+o.empid);
		return (int)(this.sal - o.sal);
	}
	
	
	
}
