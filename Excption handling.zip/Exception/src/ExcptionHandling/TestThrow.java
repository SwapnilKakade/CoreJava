package ExcptionHandling;

public class TestThrow {

	public static void main(String[] args) {
		Validate(153);
		System.out.println("Welcome");
	}

	private static void Validate(int age) {
		if(age <18) {
			throw new ArithmeticException(" Not Eligible");
			
		}
		else {
			System.out.println(" Eligible");
		}
		
	}

}
