package service;
import java.util.Set;
import java.util.Scanner;
import beans.Employee;
import dao.EmployeeDao;
import dao.EmployeeDaoImp;

public class EmployeeServiceImp implements EmployeeService {
	private EmployeeDao edao;

	public EmployeeServiceImp() {
		super();
		this.edao = new EmployeeDaoImp();
	}

	@Override
	public void AddNewEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter empid");
		int empid = sc.nextInt();
		System.out.println("Enter the name");
		String ename = sc.next();
		System.out.println("Enter the email");
		String email = sc.next();
		System.out.println("Enter the salary");
		double sal = sc.nextDouble();
		Employee e = new Employee(empid,ename,email,sal);
		edao.save(e);
	}

	@Override
	public Set<Employee> DisplayAll() {
		return edao.getAll();
		
	}

	@Override
	public Employee DisplayById(int id) {
		
		return edao.DisplayById(id);
	}

	@Override
	public Set<Employee> DisplayByName(String ename) {
		
		return edao.DisplayByName(ename);
	}

	@Override
	public Set<Employee> SortBySal() {
		
		return edao.sortData();
	}

	@Override
	public Set<Employee> SortByName() {
		
		return edao.SortByName();
	}

	@Override
	public boolean ModifySal(int id, double newsal) {
	
		return edao.ModifySalary(id,newsal);
	}

	@Override
	public boolean DeleteById(int id) {
		Scanner sc = new Scanner(System.in);
		Employee ob = edao.DisplayById(id);
		if(ob != null) {
			System.out.println("Do you want to delete "+ob.getEmpid()+" "+ob.getEname());
			String ans = sc.next();
			if(ans.equals("y"));
//			System.out.println(id);
			return edao.removeByid(id);
		}
	return false;
	}

}
