package dao;

public interface EmployeeDao {

}
