package ExcptionHandling;

public class MultipleCatchBlock {

	public static void main(String[] args) {
		try {
		//String s = null;
	//	System.out.println(s.length());
		int a[] = new int[5];
		a[5]=30/0;
		}catch(ArithmeticException e){
			System.out.println("Arithmetic Exception");
			System.out.println(e);
		
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array Index out Bound");
		}
		catch(Exception e) {
			System.out.println(" Excuted");
		}
		System.out.println("Code excuted");
	
	}

}
