package deo;
import beans.Employee;
import java.util.ArrayList;
import java.util.List;
public class EmployeeDeoImp implements EmployeeDeo {

	private static List<Employee>elist;
	static {
		elist = new ArrayList<>();
		elist.add(new Employee(1,"Sea","water",2121));
		elist.add(new Employee(2,"land","Air",21214));
		elist.add(new Employee(3,"prasad","manager",24));
		elist.add(new Employee(4,"Sss","Ceo",52121));
	}
	@Override
	public void save(Employee e) {
		elist.add(e);
		
	}
	@Override
	public List<Employee> getAllEmployee() {
		return elist;
	}
	
	
	@Override
	public Employee searchById(int empid) {
	
		int pos=elist.indexOf(new Employee(empid));
		if(pos!= -1) {
			return elist.get(pos);
		}
		return null;
	}
	@Override
	public List<Employee> SerachByName(String ename) {
		System.out.println(ename);
		List<Employee> Serachlist = new ArrayList<>();
		for(Employee ob :elist) {
			if(ob.getEname().equals(ename)) {
				Serachlist.add(ob);
			}
		}
		return Serachlist;
	}
	@Override
	public List<Employee> SortBySal() {
		List<Employee> newlist = new ArrayList<>();
		for(Employee list : elist) {
			newlist.add(list);
		}
		newlist.sort(null);
		return newlist;
	}
	@Override
	public List<Employee> SortByName() {
		List<Employee> newlist = new ArrayList<>();
		for(Employee list :elist) {
			newlist.add(list);
		}
		newlist.sort(null);
		return newlist;
	}
	@Override
	public boolean ModifyBysal(int empid, double sal) {
		Employee ob = searchById(empid);
		if(ob != null) {
			ob.setSal(sal);
			return true;
		}
		return false;
	}
	@Override
	public boolean DeleteById(int empid) {
		return elist.remove(new Employee(empid));
	}
}
