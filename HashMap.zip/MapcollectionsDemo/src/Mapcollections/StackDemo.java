package Mapcollections;

import java.util.Iterator;
import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		Stack<Integer>stk = new Stack<>();
		stk.push(10);
		stk.push(11);
		stk.push(45);
		stk.push(5);
		stk.push(4);
		System.out.println("Insert Elements :"+stk);
		
		stk.pop();
		System.out.println("Delete Element :"+stk);
		
		stk.peek();
		System.out.println("Top peek Element :"+stk);

		System.out.println("Serach 10 elements positon :"+stk.search("4"));
		
		System.out.println("The Size of Stack :"+stk.size());

		Iterator iterator = stk.iterator();
		
		while(iterator.hasNext()) {
			Object values =  iterator.next();
			System.out.println(values);
		}
	}

}
