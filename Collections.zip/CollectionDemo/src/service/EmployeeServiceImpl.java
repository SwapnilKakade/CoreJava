package service;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import beans.Employee;
import deo.EmployeeDeo;
import deo.EmployeeDeoImp;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDeo edeo;
	
	
	public EmployeeServiceImpl() {
		super();
		this.edeo = new EmployeeDeoImp();
	}


	@Override
	public void AddNewEmployee() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter empid");
		int eid = sc.nextInt();
		System.out.println("Enter name");
		String ename = sc.next();
		System.out.println("Enter Desigination");
		String desg = sc.next();
		System.out.println("Enter Salary");
		double sal = sc.nextDouble();
		Employee e = new Employee(eid,ename,desg,sal);
		edeo.save(e);
	}

	@Override
	public List<Employee> DisplayAll() {
		
		return edeo.getAllEmployee();
	}


	@Override
	public Employee searchById(int empid) {
		
		return edeo.searchById(empid);
	}


	@Override
	public List<Employee> SearchByName(String ename) {
		
		return edeo.SerachByName(ename);
	}


	@Override
	public List<Employee> SortBySal() {
		
		return edeo.SortBySal();
	}


	@Override
	public List<Employee> SortByName() {
		
		return edeo.SortByName();
	}


	@Override
	public boolean ModifyBySal(int empid, double sal) {
		return edeo.ModifyBysal(empid,sal);
	}


	@Override
	public boolean DeleteById(int empid) {
		return edeo.DeleteById(empid);
	}
	
}
