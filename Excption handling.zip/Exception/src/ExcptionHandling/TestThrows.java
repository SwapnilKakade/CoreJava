package ExcptionHandling;

import java.io.IOException;

public class TestThrows {
	void M() throws IOException {
		throw new IOException("Error");
	}

	public static void main (String[] args) {
		try{
			TestThrows th = new TestThrows();
			th.M();
		}
		catch(Exception e){
			System.out.println("Handle");
		}
		System.out.println("Code Excuted");
	}
		
}