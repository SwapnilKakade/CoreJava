import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class TestHashMap {

	public static void main(String[] args) {
	Map<String,Integer> hm = new HashMap<>();
		
	hm.put("Dac",12);
	hm.put("Dai",152);
	hm.put("Dbda",152);
	System.out.println("Value of dac " + hm.get("Dac"));
	int num =50;
	Set<String> s = hm.keySet();
		for(String k : s) {
			if(hm.get(k)>num)
				System.out.println(k);
		}
	}

}
