package deo;

import beans.Employee;
import java.util.List;
public interface EmployeeDeo {

	void save(Employee e);
	
	List<Employee> getAllEmployee();

	Employee searchById(int empid);

	List<Employee> SerachByName(String ename);

	List<Employee> SortBySal();

	List<Employee> SortByName();

	boolean ModifyBysal(int empid, double sal);

	boolean DeleteById(int empid);

	
}
