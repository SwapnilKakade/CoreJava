package FileHandlinig;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class AppendTheFile {

	public static void main(String[] args) {
		File f = new File("./Hello.txt");
		FileOutputStream fos = null ;
		try {
			if(!f.exists()) {
				FileOutputStream("./Hello.txt");
			}else {
				fos = new FileOutputStream("Hello.txt",true);
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		try(FileInputStream fis = new FileInputStream("Hello.text");
				FileOutputStream fos1 = fos;
				{
					
				}
				
	}

}
