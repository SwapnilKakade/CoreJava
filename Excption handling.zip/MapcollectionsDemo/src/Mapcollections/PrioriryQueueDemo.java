package Mapcollections;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

public class PrioriryQueueDemo {

	public static void main(String[] args) {
		PriorityQueue<Integer> q = new PriorityQueue<>();
		
		q.add(2366);
		System.out.println(q);
		q.add(34);
		System.out.println(q);
		q.add(253);
		System.out.println(q);
		q.add(265);
		System.out.println(q);		
		q.add(231);
		System.out.println(q);
		Comparator<Integer> c =(o1,o2)->{
			if(o1<o2)
				return -1;
			else if(o1==o2)
				return 0;
			else
				return 1;
		};
	PriorityQueue<Integer> q1 = new PriorityQueue<>(c);
		
		q1.offer(213);
		q1.add(341);
		q1.offer(53);
		q1.offer(35);
		q1.offer(291);
		System.out.println(q1);
		
	}

}
