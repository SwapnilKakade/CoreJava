package ExcptionHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestCopyFile {

	public static void main(String[] args) {
		FileInputStream  fis = null;
		FileOutputStream fout = null;
		try {
			fis = new FileInputStream("C:\\Users\\IET\\Desktop\\OOPS SK\\Exception\\src\\text1.txt");
			fout = new FileOutputStream("C:\\Users\\IET\\Desktop\\OOPS SK\\Exception\\src\\testcopy.txt");
			
			int i = fis.read();
			while(i != -1) {
				fout.write(i);
				System.out.println(i);
				i = fis.read();
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				fis.close();
				fout.close();
			}catch(IOException e) {
				System.out.println("Error occured");
			}
		}
	}

}
