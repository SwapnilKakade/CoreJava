package Interfaces;

public interface Myinterface1 {

	int test(int x ,int y);
}
