package dao;
import java.util.Comparator ;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import beans.Employee;

public class EmployeeDaoImp implements EmployeeDao{
	private static Map<Integer,Employee>hm;
	static {
		hm = new HashMap<>();
		hm.put(1,new Employee(111,"Swapnil","Swapnil@dfjklfd",455));
		hm.put(2,new Employee(2,"kakade","dfffd@sdf",466));
		
	}
	@Override
	public void save(Employee e) {
		hm.put(e.getEmpid(),e);
		
	}
	@Override
	public Map<Integer, Employee> getAll() {
		
		return hm;
	}
	@Override
	public Employee SearchById(int empid) {
		// TODO Auto-generated method stub
		return hm.get(empid);
	}
	@Override
	public Set<Employee> SearchByName(String ename) {
		Set<Employee> es = new HashSet<>();
		for(Integer ob : hm.keySet()) {
			if(hm.get(ob).getEname().equals(ename))
				es.add(hm.get(ob));
		}
		if(es.size()>0) {
			return es;
		}
		return null;
	}
	@Override
	public Set<Employee> SortBySal() {
		TreeSet<Employee> sal = new TreeSet<>();
		for(Integer ob : hm.keySet()) {
			sal.add(hm.get(ob));
		}
		   
		return sal ;
	}
	@Override
	public Set<Employee> SortByName() {
		Comparator<Employee> c =(o1 ,o2)->{
			return o1.getEname().compareTo(o2.getEname());
		};
		TreeSet<Employee> name = new TreeSet<>(c);
		for(Integer ob:hm.keySet()) {
			name.add(hm.get(ob));
		}
		return null;
	}

}
