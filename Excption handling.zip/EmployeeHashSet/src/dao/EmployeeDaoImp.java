package dao;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import beans.Employee;

public class EmployeeDaoImp implements EmployeeDao{
	private static Set<Employee> empset;
	static {
		empset = new HashSet<>();
		empset.add(new Employee (12,"Swapnil","fgfg@32111",11561));
		empset.add(new Employee (32,"Akash","fgfg@11",1161));
	}
	@Override
	public void save(Employee e) {
		empset.add(e);
		
	}
	@Override
	public Set<Employee> getAll() {
		return empset;
		
	}
	@Override
	public Employee DisplayById(int id) {
		for(Employee ob : empset) {
			if(ob.getEmpid()==id) {
				return ob;
			}
		}
		return null;
	}
	@Override
	public Set<Employee> DisplayByName(String ename) {
	
		Set<Employee> hset = new HashSet<>();
		for(Employee ob : empset) {
			if(ob.getEname().equals(ename)) {
				hset.add(ob);
			}
		}
		return hset;
	}
	@Override
	public Set<Employee> sortData() {
		Set<Employee> tset = new TreeSet<>();
		for(Employee ob : empset) {
			tset.add(ob);
		}
		return tset;
	}
	@Override
	public Set<Employee> SortByName() {
		Comparator<Employee> c =(o1,o2)->{
			System.out.println("in comparator for name");
			return o1.getEname().compareTo(o2.getEname());	
		};
		Set<Employee> eset = new TreeSet<>(c);
		for(Employee ob : empset) {
			eset.add(ob);
		}
		return eset;
	}
	@Override
	public boolean ModifySalary(int id, double newsal) {
		Employee e = DisplayById(id);
		if(e != null) {
			e.setSal(newsal);
			return true;
		}
		return false;
	}
	@Override
	public boolean removeByid(int id) {
		return empset.remove(new Employee(id));
	}
	

}
