package Mapcollections;
import java.util.Map;
import java.util.TreeMap;
public class TreeMapDemo {

	public static void main(String[] args) {
		Map<String,Integer> tm = new TreeMap<>();
		tm.put("A", 1);
		tm.put("B",2);
		tm.put("C", 3);
		System.out.println(tm);
		System.out.println("The value of A :"+tm.get("A"));
		tm.remove("B");
		for(String s :tm.keySet()) {
			System.out.println("Values "+tm.get(s));
		}
	}

}
