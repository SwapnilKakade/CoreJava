package service;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import beans.Employee;
import dao.EmployeeDao;
import dao.EmployeeDaoImp;

public class EmployeeServiceImp implements EmployeeService {
	private EmployeeDao edao;
	
	public EmployeeServiceImp() {
		this.edao = new EmployeeDaoImp();
	}

	@Override
	public void AddNewEamployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the empid");
		int empid =sc.nextInt();
		System.out.println("Enter the ename");
		String ename = sc.next();
		System.out.println("Enter the email");
		String email = sc.next();
		System.out.println("Enter the salary");
		double sal = sc.nextDouble();
		Employee e = new Employee(empid,ename,email,sal);
		edao.save(e);
	}

	@Override
	public Map<Integer, Employee> displayAll() {
		
		return edao.getAll();
	}

	@Override
	public Employee SearchById(int empid) {
		
		return edao.SearchById(empid);
	}

	@Override
	public Set<Employee> SearchByName(String ename) {
		
		return edao.SearchByName(ename);
	}

	@Override
	public Set<Employee> SortBySal() {
	
		return edao.SortBySal();
	}

	@Override
	public Set<Employee> SortByName() {
		
		return edao.SortByName();
	}

}
