package service;

import java.util.List;
import beans.Employee;

public interface EmployeeService {

	void AddNewEmployee();

	List<Employee> DisplayAll();

	Employee searchById(int empid);

	List<Employee> SearchByName(String ename);

	List<Employee> SortBySal();

	List<Employee> SortByName();

	boolean ModifyBySal(int empid, double sal);

	boolean DeleteById(int empid);



	
	
}
