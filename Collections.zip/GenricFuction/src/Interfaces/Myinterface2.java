package Interfaces;

public interface Myinterface2 {
	String test(String x , String y);
}
