package ExcptionHandling;

public class TestExceptionFinally {

	public static void main(String[] args) {
		try {
			int k = 50/0;
			
		}catch(ArithmeticException e) {
			System.out.println(e);
			System.out.println("Not Excute");
		}
		finally {
			System.out.println("Hello");
		}
		System.out.println("Good morning");
	}

}
