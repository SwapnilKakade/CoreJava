package service;

import java.util.Set;

import beans.Employee;

public interface EmployeeService {

	void AddNewEmployee();

	Set<Employee> DisplayAll();

	Employee DisplayById(int id);

	Set<Employee> DisplayByName(String ename);

	Set<Employee> SortBySal();
	
	Set<Employee> SortByName();

	boolean ModifySal(int id, double newsal);

	boolean DeleteById(int id);




}
