import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class HashMap1 {

	public static void main(String[] args) {
		Map<String,Integer> hm = new HashMap<>();
		hm.put(null,null);
		hm.put("Swapnil", 1);
		hm.put("df",2);
		if(!hm.containsKey("df"))
			hm.put("xxx",3);
		System.out.println(hm);
		hm.remove("Swapnil");
		System.out.println(hm);
		
		
		
	}

}
