package Enum;

public class TestEnum {
	

	public static void main(String[] args) {
		Coffee e = Coffee.big;
		switch(e){
			case small:
				System.out.println("Small Selected");
				System.out.println("Size " +e.getSize());
				System.out.println("Price "+ e.getPrice());
				break;
			
			case medium:
				System.out.println("Medium Selectd");
				System.out.println("Size "+e.getSize());
				System.out.println("Price "+e.getPrice());
				break;
			case big:
				System.out.println("Big Selectd");
				System.out.println("Size "+e.getSize());
				System.out.println("Price "+e.getPrice());
				break;
		}

	}

}
