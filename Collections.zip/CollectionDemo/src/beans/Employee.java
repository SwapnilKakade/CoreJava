package beans;

public class Employee implements Comparable<Employee> {
	private int empid ;
	private String ename ;
	private String desg;
	private double sal;

	
	public Employee(int empid) {
		this.empid = empid;
		this.ename = null;
		this.desg = null;
		this.sal = 0;
	}

	public Employee(int empid, String ename, String desg, double sal) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.desg = desg;
		this.sal = sal;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getDesc() {
		return desg;
	}

	public void setDesc(String desg) {
		this.desg = desg;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}
   

	
	@Override
	public boolean equals(Object obj) {
		
		return this.empid==((Employee)obj).empid;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", desc=" + desg + ", sal=" + sal + "]";
	}

	@Override
	public int compareTo(Employee o) {
		
		return (int)(this.sal - o.sal);
	}

	
	
}
