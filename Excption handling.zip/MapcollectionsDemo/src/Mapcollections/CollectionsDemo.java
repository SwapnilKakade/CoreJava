package Mapcollections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollectionsDemo {

	public static void main(String[] args) {
	List<Integer> list = new ArrayList<>();
	list.add(41);
	list.add(55);
	list.add(545);
	list.add(45);
	list.add(8);
	Collections.sort(list);
	System.out.println(list);
	System.out.println("The value of minimum :"+Collections.min(list));
	System.out.println("The value of maximum :"+Collections.max(list));
	Collections.shuffle(list);
	System.out.println(list);
	}

}
