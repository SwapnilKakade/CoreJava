package Test;

import Interfaces.Myinterface1;
import beans.MyClass;

public class TestMyClass {

	public static void main(String[] args) {
		Myinterface1 ob = new MyClass();
		ob.test(12, 5);
		Myinterface1 ob2 = (a,b)->a+b;
	}

}
