package ExcptionHandling;

import java.rmi.AccessException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionDemo {

	private static int divide(int i, int j) {
		try {
			int ans = i/j;
			return ans;
		}catch(ArithmeticException e) {
			System.out.println(e);
			throw e;
		}
		
	}
	
	public static void main(String[] args) {
	try {
		Scanner sc = new Scanner(System.in);
			for (int k = 0; k<3 ; k++)
			{
				try {
					System.out.println("Enter the number");
					int i = sc.nextInt();
					int j = sc.nextInt();
					int ans =divide(i,j);
					System.out.println(ans);
				}
				catch(InputMismatchException | ArithmeticException e)
				{
					System.out.println("Pls Enter number");
					System.out.println(e.getMessage());
					sc.next();
				}
				catch(Exception e) 
				{
					System.out.println("Error occured");
					System.out.println(e.getMessage());
				}
			
				
			}
		}
	finally
	{
	System.out.println("Done");
	}
	}

}

