package test;

import service.EmployeeServiceImp;
import service.EmployeeService;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import beans.Employee;

public class TestEmployeeMangt {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeService es = new EmployeeServiceImp();
		int choice;
		do {
			System.out.println("1. Add new Employee\n"
					+ "2. Display all\n "
					+ "3. Disaly by id\n "
					+ "4. Display by name\n"
					+ "5. sort by sal\n"
					+ "6. sort by name\n "
					+ "7. modify sal\n"
					+ "8. delete by id\n"
					+ "9.exit");
			choice = sc.nextInt();
			switch(choice) {
				case 1:
					es.AddNewEamployee();
					break;
				case 2 :
					Map<Integer,Employee> s = es.displayAll();
					s.keySet().forEach(key ->System.out.println(key+"----->"+s.get(key)));
					break;
				case 3 :
					System.out.println("Enter the empid");
					int empid = sc.nextInt();
					Employee e = es.SearchById(empid);
					if(e != null) {
						System.out.println(e);
					}
					else {
						System.out.println("Not found");
					}
					break;
				case 4 :
					System.out.println("Enter the name");
					String ename = sc.next();
					Set<Employee> elist = es.SearchByName(ename);
					if(elist != null) {
						elist.forEach(a->{System.out.println(a);});
					}
					else {
						System.out.println("Not found");
					}
					
					break;
				case 5 :
					elist = es.SortBySal();
					elist.forEach(a->{System.out.println(a);});
					break;
				case 6:
					elist = es.SortByName();
					elist.forEach(a->{System.out.println(a);});
				case 9 :
				System.out.println("Thank you");
				break;
				
				default :
				
				sc.close();
			}
			
		}while(choice != 0);

	}

}
