package Test;

import java.util.List;
import java.util.Scanner;
import beans.Employee;
import service.EmployeeService;
import service.EmployeeServiceImpl;

public class TestEmployeeList {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeService es = new EmployeeServiceImpl();
		int choice ;
		do {
			System.out.println("1.Add New Employee\n"
					+ "2.Display All\n"
					+ "3.Search by id\n"
					+ "4.Display by name\n"
					+ "5.Sort by sal\n"
					+ "6.Sort by Name\n"
					+ "7.Modify salary\n"
					+ "8.Delete by id\n"
					+ "9.Exit\n");
			choice = sc.nextInt();
			
			switch(choice) {
				case 1 :
					es.AddNewEmployee();
					break;
				case 2 :
					List<Employee> list = es.DisplayAll();
					list.forEach(ob->{System.out.println(ob);});
					break ;
				case 3:
					System.out.println("Enter employee empid");
					int empid = sc.nextInt();
					Employee e = es.searchById(empid);
					if(e != null) {
						System.out.println(e);
					}
					else {
						System.out.println("Not found");
					}
					break;
				case 4:
					System.out.println("Enter the name");
					String ename = sc.next();
					List<Employee> namelist = es.SearchByName(ename);
					if(namelist != null) {
						namelist.forEach(a->{System.out.println(a);});
					}
					else {
						System.out.println("Not found");
					}
					break;
				case 5:
					List<Employee> elist = es.SortBySal();
					elist.forEach(a->{System.out.println(a);});
					break;
				case 6:
					elist = es.SortByName();
					elist.forEach(a->{System.out.println(a);});
					break;
				case 7:
					System.out.println("Enter id");
					empid = sc.nextInt();
					System.out.println("Enter Salary");
					double sal = sc.nextDouble();
					boolean Status = es.ModifyBySal(empid,sal);
					if(Status) {
						System.out.println("Modify Successfully");
					}
					else {
						System.out.println("Not found");
					}
					break;
				case 8:
					System.out.println("Enter empid");
					empid =sc.nextInt();
					boolean status = es.DeleteById(empid);
					if(status) {
						System.out.println("Delete id");
					}
					else {
						System.out.println("Not found");
					}
					break;
	
				case 9 :
					sc.close();
					System.out.println("Thank you");
					break ;
				default :
			}
			
		}while(choice != 0);
		
		sc.close();
		
	}
	
	
}
