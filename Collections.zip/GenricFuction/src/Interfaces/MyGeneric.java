package Interfaces;

public interface MyGeneric<T> {
	T test (T x,T y);
}
