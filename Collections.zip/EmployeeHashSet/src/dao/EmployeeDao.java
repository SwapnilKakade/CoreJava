package dao;

import beans.Employee;
import java.util.Set;
public interface EmployeeDao {

	void save(Employee e);

	Set<Employee> getAll();

	Employee DisplayById(int id);

	Set<Employee> DisplayByName(String ename);

	Set<Employee> sortData();

	Set<Employee> SortByName();

	boolean ModifySalary(int id, double newsal);

	boolean removeByid(int id);

}
