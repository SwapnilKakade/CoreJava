package ExcptionHandling;

import java.io.IOException;

class M{

	void Method() throws IOException{
		System.out.println("handle");
	}
	
}
public class TestThrows1 {

	public static void main(String[] args) throws IOException{
		M m = new M();
		m.Method();
		System.out.println("normal");
	}

}
