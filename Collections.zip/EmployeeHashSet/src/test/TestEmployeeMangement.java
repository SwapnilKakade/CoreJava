package test;

import java.util.Scanner;
import java.util.Set;

import service.EmployeeService;
import service.EmployeeServiceImp;
import beans.Employee;

public class TestEmployeeMangement {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeService es = new EmployeeServiceImp();
		int ch;
		
		do {
			System.out.println(""
					+ "1. Add new Employee\n "
					+ "2. Display all\n "
					+ "3. Dispaly by id\n "
					+ "4. Display by name\n"
					+ "5. Sort by sal\n "
					+ "6. Sort by name\n "
					+ "7. Modify sal\n "
					+ "8. Delete by id\n"
					+ "9. Exit");
			ch = sc.nextInt();
			switch(ch) {
				case 1:
					es.AddNewEmployee();
					break;
				case 2 :
					Set<Employee> s=es.DisplayAll();
					s.forEach(a->{System.out.println((a));});
					break;
				case 3 :
					System.out.println("Enter id");
					int id = sc.nextInt();
					Employee e = es.DisplayById(id);
					if(e != null) {
						System.out.println(e);
					}
					else {
						System.out.println("Not found");
					}
					break;
				case 4 :
					System.out.println("Enter the name");
					String ename = sc.next();
					Set<Employee> eset = es.DisplayByName(ename);
					if(eset != null) {
						eset.forEach(a->{System.out.println(a);});
					}
					else {
						System.out.println("Not found");
					}
					break;
				case 5 :
					 eset = es.SortBySal();
					eset.forEach(a->{System.out.println(a);});
					break;
				case 6 :
					 eset = es.SortByName();
					eset.forEach(a->{System.out.println(a);});
					break;
				case 7:
					System.out.println("Enter id");
					id = sc.nextInt();
					System.out.println("Enter new salary");
					double newsal = sc.nextDouble();
					boolean status = es.ModifySal(id,newsal);
					if(status) {
						System.out.println("Modify Successfully");
					}
					else {
						System.out.println("Not found");
					}
					break;
				case 8 :
					System.out.println("Enter id");
					id = sc.nextInt();
					status = es.DeleteById(id);
					if(status) {
						System.out.println("Delete successfully");
					}
					else {
						System.out.println("Not found");
					}
					break;
				case 9 :
					System.out.println("Thank you for visiting");
					break;
				default:
			}
		//	sc.close();
		}while(ch != 0);

	}

}
