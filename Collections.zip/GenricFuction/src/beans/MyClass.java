package beans;

import Interfaces.Myinterface1;

public class MyClass implements Myinterface1 {

	@Override
	public int test(int x, int y) {
		
		return x +y;
	}
	
}
